<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class BaseController extends Controller
{
    
    public function handleResponse($result, $msg)
    {
    	$res = [
            'responseCode'        => '100',
            'responseMessage'     => 'Successfully',
            'responseDescription' => $msg,
            'data'                => $result,
        ];
        return response()->json($res, 200);
    }

    public function handleError($error, $errorMsg = [], $code = 102)
    {
    	$res = [
            'responseCode'          => $code,
            'responseMessage'       => 'Error',
            'responseDescription'   => $error,
        ];
        if(!empty($errorMsg)){
            $res['data'] = $errorMsg;
        }
        return response()->json($res);
    }
}
