<?php

namespace App\Http\Controllers\App;

use Carbon\Carbon;
use App\Models\Company;
use App\Models\Attendance;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\App\BaseController;

class AttendanceController extends BaseController
{
    public $employeeID;
    public $company;
    // check in funciton
    public function checkIn(Request $request)
    {
        $this->employeeID = Auth::user()->id;
        $this->company = Company::find(Auth::user()->company_id);

        $today = Carbon::now();
        $yesterday = Carbon::yesterday();
        
        // Yesterday office start time
        /** @var Carbon $yesterday_end_time */
        $yesterday_end_time = clone $this->getOfficeEndTime($yesterday);
        $yesterday_end_time->subDay();

        /** @var Carbon $yesterday_start_time */
        $yesterday_start_time = clone $this->getOfficeStartTime($yesterday);
        $yesterday_start_time->subDay();

        // Today and yesterday dates
        $dates = [$today->format("Y-m-d"), $yesterday->format("Y-m-d")];

        $today_attendance = Attendance::where('date', $dates[0])
            ->where('employee_id', '=', $this->employeeID)
            ->orderBy('date')
            ->first();

        $yesterday_attendance = Attendance::where('date', $dates[1])
            ->where('employee_id', '=', $this->employeeID)
            ->orderBy('date')
            ->first();


        $working_attendance = null;

        // If less than 6 hours have passed since yesterday's office end time,
        // allow clocking for yesterday

        if ($today->diffInHours($yesterday_end_time) <= 6) {
            $working_attendance = $yesterday_attendance;
            $working_day = $yesterday;
        } else {
            $working_attendance = $today_attendance;
            $working_day = $today;
        }

        $cur_time = $today->format('H:i:s');
        $time = Carbon::now()->timezone($this->company->timezone)->format('h:i A');
        $date_time = Carbon::now()->timezone($this->company->timezone)->format("Y-m-d H:i:s");

        // Check today's attendance
        if ($working_attendance != null) {
            if ($working_attendance->status == "absent") {
                return $this->handleError('You have been marked absent for today', '', 102);
            }
            $working_attendance->clock_in = $cur_time;
            $working_attendance->clock_in_ip_address = $_SERVER['REMOTE_ADDR'];
            $working_attendance->status = 'present';
            $working_attendance->notes = $request->notes;
            $working_attendance->working_from = $request->work_from;
            $working_attendance->office_start_time = $this->company->office_start_time;
            $working_attendance->office_end_time = $this->company->office_end_time;

            if ($this->company->late_mark_after != null) {
                if ($working_attendance->clock_in->diffInMinutes($this->company->getOfficeStartTime($working_day)) <
                    $this->company->late_mark_after * -1) {
                    $working_attendance->is_late = 1;
                } else {
                    $working_attendance->is_late = 0;
                }
            }
            $working_attendance->save();
            $data = ['time' => $time, 'timeDiff' => $today->diffForHumans(), 'time_date' => $date_time];

            return $this->handleResponse($data, 'You have successfully clocked in');
        }


        $new_attendance = new Attendance();
        $new_attendance->employee_id = $this->employeeID;;
        $new_attendance->date = $today->format("Y-m-d");
        $new_attendance->status = 'present';
        $new_attendance->clock_in = $cur_time;
        $new_attendance->clock_in_ip_address = $_SERVER['REMOTE_ADDR'];
        $new_attendance->notes = $request->notes;
        $new_attendance->working_from = $request->work_from;
        $new_attendance->office_start_time = $this->company->office_start_time;
        $new_attendance->office_end_time = $this->company->office_end_time;


        if ($this->company->late_mark_after != null) {
            if ($new_attendance->clock_in->diffInMinutes($this->company->getOfficeStartTime($today), false) <
                $this->company->late_mark_after * -1) {
                $new_attendance->is_late = 1;
            } else {
                $new_attendance->is_late = 0;
            }
        }
        $new_attendance->save();
        $data = ['time' => $time, 'timeDiff' => $today->diffForHumans(), 'time_date' => $date_time];

        return $this->handleResponse($data, 'check in Successfully');

    }

    function checkOut(Request $request)
    {
        // get the employee id ang company data
        $this->employeeID = Auth::user()->id;
        $this->company = Company::find(Auth::user()->company_id);

        // Creating date objects
        $today = Carbon::now();
        $yesterday = Carbon::yesterday();

        // Yesterday office start time
        /** @var Carbon $yesterday_end_time */
        $yesterday_end_time = clone $this->getOfficeEndTime($yesterday);
        $yesterday_end_time->subDay();

        /** @var Carbon $yesterday_start_time */
        $yesterday_start_time = clone $this->getOfficeStartTime($yesterday);
        $yesterday_start_time->subDay();

        // Today and yesterday dates
        $dates = [$today->format("Y-m-d"), $yesterday->format("Y-m-d")];

        $today_attendance = Attendance::where('date', $dates[0])
            ->where('employee_id', '=', $this->employeeID)
            ->orderBy('date')
            ->first();

        $yesterday_attendance = Attendance::where('date', $dates[1])
            ->where('employee_id', '=', $this->employeeID)
            ->orderBy('date')
            ->first();

        $working_attendance = null;

        // If less than 6 hours have passed since yesterday's office end time,
        // allow clocking for yesterday

        if ($today->diffInHours($yesterday_end_time) <= 6) {
            $working_attendance = $yesterday_attendance;
        } else {
            $working_attendance = $today_attendance;
        }

        $cur_time = $today->format('H:i:s');

        // Check today's attendance
        if ($working_attendance != null) {
            if ($working_attendance->status == "absent") {
                return $this->handleError('You have been marked absent for today', '', 102);                
            }
            if ($working_attendance->clock_in != null) {

                if ($working_attendance->clock_out != null) {
                    return $this->handleError('Your attendance for today has already been marked', '', 103);
                }
                $working_attendance->clock_out = $cur_time;
                $working_attendance->clock_out_ip_address = $_SERVER['REMOTE_ADDR'];
                $working_attendance->save();

                $clock_out = Carbon::now()->timezone($this->company->timezone);

                $data = ['unset_time' => $clock_out->format("h:i A"), 'unset_time_diff' => $clock_out->diffForHumans(), 'date_time' => $clock_out->format('Y-m-d H:i:s')];
                return $this->handleResponse($data, 'Clock out time was set successfully');
            }

            return $this->handleError('You have to clock in first', '', 103);
        }
        return $this->handleError('You have to clock in first', '', 103);

    }

    public function getOfficeEndTime(Carbon $date = null)
    {
        if ($date == null) {
            $date = Carbon::now();
        }

        $dateStr = $date->format("Y-m-d");

        $end = Carbon::createFromFormat("Y-m-d H:i:s", $dateStr . " " . $this->company->office_end_time);
        $start = Carbon::createFromFormat("Y-m-d H:i:s", $dateStr . " " . $this->company->office_start_time);

        if ($end < $start) {
            $end->addDay();
        }

        return $end;
    }

    public function getOfficeStartTime(Carbon $date = null)
    {
        if ($date == null) {
            $date = Carbon::now();
        }

        $dateStr = $date->format("Y-m-d");

        $start = Carbon::createFromFormat("Y-m-d H:i:s", $dateStr . " " . $this->company->office_start_time);

        return $start;
    }

}
// [employee_id] => 1
//             [date] => 2021-12-28
//             [status] => present
//             [clock_in] => 08:31:55
//             [clock_in_ip_address] => 127.0.0.1
//             [notes] => 
//             [working_from] => 
//             [office_start_time] => 06:00:00
//             [office_end_time] => 14:00:00
//             [is_late] => 1