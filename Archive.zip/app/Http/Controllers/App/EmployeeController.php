<?php

namespace App\Http\Controllers\App;


use Carbon\Carbon;
use App\Models\Company;
use App\Models\Attendance;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\App\FrontBaseController;

class EmployeeController extends BaseController
{
    public $employeeID;
    public $setting;

    public function getUserData()
    {
        $data = [];
        $today = Carbon::now(); 
        $data['today'] = $today;
        $this->employeeID = Auth::user()->id;
        $attendance = Attendance::where('employee_id', $this->employeeID)->whereDate('created_at', $today)->exists();
        if ($attendance) {
            $attendance = Attendance::where('employee_id', $this->employeeID)->whereDate('created_at', $today)->first();
        }
        $data['today_attendance'] = $attendance;
        $this->attendanceActive = 'active';        

        $timeZone = Company::find(Auth::user()->company_id)->timezone;
        
        $data['timeZone'] = $timeZone;

        $local_time = Carbon::now(new \DateTimeZone($timeZone));
        $data['local_time'] = $local_time;
        $ip_address = $_SERVER['REMOTE_ADDR'];
        return $this->handleResponse($data, 'attendance data');
    }


    // get attendance 
    public function getAttendance()
    {
        $this->employeeID = Auth::user()->id;
        $attendance = Attendance::where('created_at',  '>', now()->subDays(30)->endOfDay())
            ->where('employee_id', '=', $this->employeeID)
            ->orderBy('date')
            ->get();
        return $this->handleResponse($attendance, 'attendance data');
    }


}
