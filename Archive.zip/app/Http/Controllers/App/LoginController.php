<?php

namespace App\Http\Controllers\App;

use App\Models\User;
use App\Models\Branch;
use App\Models\Company;
use App\Models\Employee;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\App\BaseController as BaseController;

class LoginController extends BaseController
{
    public $employee;
    public $company;
    public $branch;

    //login funciton
    public function login(Request $request)
    {
        if(auth()->attempt(['email' => $request->email, 'password' => $request->password])){ 
            $this->employee = Auth::user();
            
            
            return $this->checkDeviceId($request->device_id);
            $this->getCompany();
            $this->getBranch();


            
            if ($this->employee->device_id != $request->device_id || $this->employee->device_status == 0) {
                return $this->handleResponse('', 'Please send to admin to activate device id!');
            }
            
            $success['name']    =  $this->employee->full_name;
            $success['gender']  =  $this->employee->gender;
            $success['status']  =  $this->employee->status;
            $success['cmopany_id']    =  $this->company->id;
            $success['company_name']    =  $this->company->company_name;
            $success['branch_id']    =  $this->branch->id;
            $success['branch_name']    =  $this->branch->name;
            $success['token']   =  $this->employee->createToken('Token Name')->accessToken; 
            return $this->handleResponse($success, 'User logged-in!');
        } 
        else{ 
            return $this->handleError('Unauthorised.', 'Unauthorised');
        } 
    }


    public function getCompany() : void
    {
        $this->company = Company::find($this->employee->company_id);
    }

    public function getBranch() : void
    {
        $this->branch = Branch::find($this->employee->branch_id);
    }

    public function checkDeviceId($deviceId)
    {
        if ($this->employee->device_id != null) {
            return true;
        }
        
        $employee = Employee::find($this->employee->id);
        $employee->device_id = $deviceId;
        $employee->device_status = 0;
        $employee->update();
    }

    public function getUserData()
    {
        $employeeID = Auth::user()->id;
        $employee = Employee::with('company','barnch')->find($employeeID);
        return $this->handleResponse($employee, 'Employee retrieved.');
        // return response()->json(Auth::user(), 200);
    }
}
