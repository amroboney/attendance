<?php


namespace App\Models;
use Illuminate\Database\Eloquent\Model;

// use Froiden\RestAPI\ApiModel;

class BaseModel extends Model
{

}
